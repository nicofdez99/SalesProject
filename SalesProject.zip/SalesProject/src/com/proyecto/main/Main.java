package com.proyecto.main;

public class Main {
    /**
     * Runnable stub para la segunda fase del proyecto (generación de reportes).
     *
     * En la entrega 1 basta con que exista este archivo (con método main) en el
     * proyecto Eclipse. En entregas posteriores implementarás aquí:
     *  - lectura de products_info.txt y salesmen_info.txt
     *  - agregación de ventas desde generated_input/sales/*.txt
     *  - creación de reportes:
     *      * vendedores_ordenados.csv  (Documento;ID;Nombres;Apellidos;RecaudoTotal)
     *      * productos_ordenados.csv  (ID;Nombre;Precio;CantidadTotalVendida) u otro formato pedido
     *
     * Reglas: no pedir entrada al usuario.
     */
    public static void main(String[] args) {
        System.out.println("Clase 'main' placeholder. Implementa aquí el procesamiento en la Fase 2.");
    }
}
