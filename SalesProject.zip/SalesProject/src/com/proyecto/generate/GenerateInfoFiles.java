package com.proyecto.generate;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

/**
 * GenerateInfoFiles
 *
 * Clase con método main que genera archivos planos pseudoaleatorios para:
 *  - archivos de ventas por vendedor (uno o varios archivos por vendedor)
 *  - archivo con información de vendedores
 *  - archivo con información de productos
 *
 * Requisitos del proyecto del módulo:
 *  - No solicita entrada al usuario (todo configurable por constantes)
 *  - Métodos disponibles para pruebas:
 *      - createSalesMenFile(int randomSalesCount, String name, long id)
 *      - createProductsFile(int productsCount)
 *      - createSalesManInfoFile(int salesmanCount)
 *
 * Diseñado para Java 8 y para ser ejecutado desde Eclipse.
 *
 * @author
 * @version 1.0
 */
public class GenerateInfoFiles {

    /* ------------------ CONFIGURACIÓN (ajusta aquí sin cambiar lógica) ------------------ */

    /** Carpeta donde se guardarán los archivos generados (relativa al proyecto) */
    private static final String OUTPUT_DIR = "generated_input";

    /** Cantidad de vendedores a generar para el archivo de información de vendedores */
    private static final int DEFAULT_SALESMEN_COUNT = 10;

    /** Cantidad de productos a generar */
    private static final int DEFAULT_PRODUCTS_COUNT = 50;

    /**
     * Número promedio de ventas por archivo de vendedor (se crea un archivo por vendedor;
     * además generamos aleatoriamente entre 1 y MAX_SALES_PER_FILE archivos por vendedor si
     * ENABLE_MULTIPLE_FILES_PER_SELLER = true)
     */
    private static final int AVERAGE_SALES_PER_FILE = 100;

    /** Habilita la creación de múltiples archivos por vendedor (extra del enunciado). */
    private static final boolean ENABLE_MULTIPLE_FILES_PER_SELLER = true;

    /** Máximo número de archivos por vendedor cuando ENABLE_MULTIPLE_FILES_PER_SELLER = true */
    private static final int MAX_FILES_PER_SELLER = 3;

    /** Random con semilla temporal (puedes fijarla para reproducibilidad) */
    private static final Random RAND = new Random();

    /* ------------------ LISTAS ESTÁTICAS PARA NOMBRES (se pueden ampliar) ------------------ */
    private static final String[] FIRST_NAMES = {
            "Carlos","Mariana","Andrés","Laura","Javier","Sofía","Diego","Valentina","Luis","Camila",
            "Sebastián","Daniela","Mateo","Alejandra","Pablo","Catalina","Felipe","Andrea","Juan","Isabella"
    };

    private static final String[] LAST_NAMES = {
            "González","Rodríguez","Martínez","Gómez","López","Hernández","Pérez","Torres","Ramírez","Santos",
            "Vargas","Castro","Mendoza","Rojas","Cruz","Morales","Ortiz","Silva","Navarro","Sosa"
    };

    private static final String[] DOC_TYPES = {"CC","CE","TI","NIT","PP"}; // ejemplos

    private static final String PRODUCT_NAME_BASE = "Producto";

    /* ------------------ MÉTODOS PÚBLICOS REQUERIDOS ------------------ */

    /**
     * Crea un archivo de ventas pseudoaleatorio para un vendedor (un archivo).
     * Este método cumple con la firma requerida en el enunciado:
     *
     * createSalesMenFile(int randomSalesCount, String name, long id)
     *
     * Formato por línea (una venta por línea):
     * TipoDocumentoVendedor;NúmeroDocumentoVendedor;IDProducto1;CantidadProducto1;IDProducto2;CantidadProducto2;...
     *
     * @param randomSalesCount número de ventas (líneas) a generar en el archivo
     * @param name nombre del vendedor (usado sólo para el nombre del archivo)
     * @param id documento del vendedor
     * @throws IOException si ocurre error de E/S
     */
    public static void createSalesMenFile(int randomSalesCount, String name, long id) throws IOException {
        createSalesMenFiles(randomSalesCount, name, id, 1);
    }

    /**
     * Variante privada usada para implementar la posibilidad de múltiples archivos por vendedor.
     *
     * @param randomSalesCount total promedio de ventas a generar por archivo
     * @param name nombre del vendedor
     * @param id documento
     * @param filesCount cantidad de archivos a generar para este vendedor
     * @throws IOException on IO error
     */
    private static void createSalesMenFiles(int randomSalesCount, String name, long id, int filesCount) throws IOException {
        File dir = new File(OUTPUT_DIR, "sales");
        dir.mkdirs();

        String docType = sample(DOC_TYPES);

        for (int fileIdx = 1; fileIdx <= filesCount; fileIdx++) {
            String filename = String.format("sales_%s_%d_part%d.txt", docType, id, fileIdx);
            File out = new File(dir, filename);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(out))) {
                int lines = Math.max(1, randomSalesCount + RAND.nextInt(Math.max(1, randomSalesCount / 3)));
                // Cada línea = una venta. En cada venta incluimos entre 1 y 5 productos distintos.
                for (int i = 0; i < lines; i++) {
                    int productsInSale = 1 + RAND.nextInt(5); // entre 1 y 5 productos por venta
                    StringBuilder sb = new StringBuilder();
                    sb.append(docType).append(";").append(id); // parte del vendedor
                    // Añadir pares IDProducto;Cantidad
                    Set<String> usedProductIds = new HashSet<>();
                    for (int p = 0; p < productsInSale; p++) {
                        String productId = String.format("P%04d", 1 + RAND.nextInt(DEFAULT_PRODUCTS_COUNT));
                        // evitar repetir el mismo producto en la misma venta
                        if (usedProductIds.contains(productId)) continue;
                        usedProductIds.add(productId);

                        int qty = 1 + RAND.nextInt(10); // 1 a 10 unidades vendidas
                        // asegurar qty positiva (coherencia)
                        if (qty <= 0) qty = 1;
                        sb.append(";").append(productId).append(";").append(qty);
                    }
                    writer.write(sb.toString());
                    writer.newLine();
                }
            }
        }
    }

    /**
     * Crea (un) archivo(s) de vendedores con formato:
     * TipoDocumento;NúmeroDocumento;NombresVendedor1;ApellidosVendedor1
     *
     * @param salesmanCount número de vendedores a generar
     * @throws IOException si falla E/S
     */
    public static void createSalesManInfoFile(int salesmanCount) throws IOException {
        File dir = new File(OUTPUT_DIR);
        dir.mkdirs();
        File out = new File(dir, "salesmen_info.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(out))) {
            for (int i = 0; i < salesmanCount; i++) {
                String docType = sample(DOC_TYPES);
                long id = 10000000L + Math.abs(RAND.nextLong() % 90000000L);
                String firstName = sample(FIRST_NAMES);
                String lastName = sample(LAST_NAMES);
                writer.write(String.format("%s;%d;%s;%s", docType, id, firstName, lastName));
                writer.newLine();

                // Si habilitado: creamos uno o varios archivos de ventas para este vendedor
                if (ENABLE_MULTIPLE_FILES_PER_SELLER) {
                    int filesForSeller = 1 + RAND.nextInt(MAX_FILES_PER_SELLER);
                    for (int f = 0; f < filesForSeller; f++) {
                        // promedio AVERAGE_SALES_PER_FILE ventas por archivo
                        createSalesMenFiles(AVERAGE_SALES_PER_FILE, firstName + "_" + lastName, id, 1);
                    }
                } else {
                    // crear un solo archivo por vendedor
                    createSalesMenFiles(AVERAGE_SALES_PER_FILE, firstName + "_" + lastName, id, 1);
                }
            }
        }
    }

    /**
     * Crea un archivo con información de productos con formato:
     * IDProducto;NombreProducto;PrecioPorUnidad
     *
     * @param productsCount número de productos a generar
     * @throws IOException si falla E/S
     */
    public static void createProductsFile(int productsCount) throws IOException {
        File dir = new File(OUTPUT_DIR);
        dir.mkdirs();
        File out = new File(dir, "products_info.txt");
        DecimalFormat priceFmt = new DecimalFormat("#.00");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(out))) {
            for (int i = 1; i <= productsCount; i++) {
                String id = String.format("P%04d", i);
                String name = PRODUCT_NAME_BASE + " " + i;
                // generar precio pseudoaleatorio entre 1000 y 100000 (asegurar positivo)
                double price = 1000.0 + RAND.nextDouble() * 99000.0;
                if (price < 0) price = Math.abs(price);
                writer.write(String.format("%s;%s;%s", id, name, priceFmt.format(price)));
                writer.newLine();
            }
        }
    }

    /* ------------------ UTILIDADES ------------------ */

    /**
     * Devuelve un elemento aleatorio de un arreglo.
     * @param arr arreglo
     * @return elemento seleccionado
     */
    private static <T> T sample(T[] arr) {
        return arr[RAND.nextInt(arr.length)];
    }

    /* ------------------ MÉTODO main (genera todo lo necesario para la entrega 1) ------------------ */

    /**
     * main
     *
     * Genera:
     *  - un archivo products_info.txt con DEFAULT_PRODUCTS_COUNT productos
     *  - un archivo salesmen_info.txt con DEFAULT_SALESMEN_COUNT vendedores
     *  - múltiples archivos de ventas por vendedor (en carpeta generated_input/sales/)
     *
     * No pide interacción al usuario; imprime mensajes de estado en consola.
     *
     * @param args no utilizados
     */
    public static void main(String[] args) {
        System.out.println("Iniciando generación de archivos pseudoaleatorios...");

        try {
            // 1) Productos
            System.out.println("Generando archivo de productos (" + DEFAULT_PRODUCTS_COUNT + ")...");
            createProductsFile(DEFAULT_PRODUCTS_COUNT);
            System.out.println("Archivo products_info.txt generado en: " + new File(OUTPUT_DIR).getAbsolutePath());

            // 2) Vendedores (y archivos de ventas por vendedor)
            System.out.println("Generando archivo de información de vendedores (" + DEFAULT_SALESMEN_COUNT + ")...");
            createSalesManInfoFile(DEFAULT_SALESMEN_COUNT);
            System.out.println("Archivo salesmen_info.txt generado en: " + new File(OUTPUT_DIR).getAbsolutePath());
            System.out.println("Archivos de ventas generados en la subcarpeta: " + new File(OUTPUT_DIR, "sales").getAbsolutePath());

            System.out.println("Generación completada con éxito.");
        } catch (IOException e) {
            System.err.println("Ocurrió un error al generar archivos: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
